import { Component, OnInit } from "@angular/core";
import { first } from "rxjs/operators";

import { Audit } from "@/_models";
import { AuditService, AuthenticationService } from "@/_services";

@Component({ templateUrl: "audit.component.html" })
export class AuditComponent implements OnInit {
  audits = [];
  currentUser: any;
  filterTerm: any;
  currentDate:any
  date:any
  constructor(
    private authenticationService: AuthenticationService,
    private auditService: AuditService
  ) {}

  ngOnInit() {
    this.loadAllAudits();
    this.currentDate = new Date();
    this.date = this.currentDate.toLocaleDateString()
    console.log(this.date);
}
    

  private loadAllAudits() {
    this.auditService
      .getAll()
      .pipe(first())
      .subscribe((audits) => {
        this.audits = audits;
        console.log(this.audits);
      });
  }

  pageSize = 10;
  currentPage = 1;
  totalPages: any;

  sortProperties = ["loginTime", "logoutTime", "_id"];
  selectedProperty = "_id";

  get startingIndex(): number {
    return (this.currentPage - 1) * this.pageSize;
  }

  get endingIndex(): number {
    return this.startingIndex + this.pageSize;
  }

  get paginatedData(): number[] {
    return this.audits.slice(this.startingIndex, this.endingIndex);
  }

  setPage(page: number) {
    this.currentPage = page;
  }

  

}
