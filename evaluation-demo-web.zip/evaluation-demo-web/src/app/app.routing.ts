﻿import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { RegisterComponent } from './register';
import { AuditComponent } from './audit';
import { AuthGuard } from './_helpers';
import { DashboardComponent } from './dashboard/dashboard.component';

const routes: Routes = [
    { path: '', redirectTo:'audit',pathMatch:'full'},
    { path: 'home', component: HomeComponent },    
    { path: 'audit', component: AuditComponent},
    { path:'dashboard',component:DashboardComponent},
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },

    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const appRoutingModule = RouterModule.forRoot(routes);