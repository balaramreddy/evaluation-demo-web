import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'orderBy'
  })
  export class OrderByPipe implements PipeTransform {
    transform(value: any[], property: string): any[] {
      if (!value || !value.sort) {
        return value;
      }
      return value.sort((a, b) => {
        return a[property].localeCompare(b[property]);
      });
    }
  }